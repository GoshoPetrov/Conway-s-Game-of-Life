﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefiningClasses
{
    public class Family
    {
        List<Person> people;

        public Family()
        {
            this.people = new List<Person>();
        }

        public void AddMember(Person member)
        {
            this.people.Add(member);
        }

        public Person GetOldestMember()
        {
            Person result = null;
            
            foreach (Person item in this.people)
            {
                if (result == null)
                {
                    result = item;
                }
                else if (result.Age < item.Age)
                {
                    result = item;
                }
            }

            return result;
        }
    }
}
