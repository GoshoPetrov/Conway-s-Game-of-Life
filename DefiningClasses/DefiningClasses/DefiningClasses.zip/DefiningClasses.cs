﻿namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            Family family = new Family();
            for(int i = 0; i < n; i++)
            {
                string[] parst = Console.ReadLine().Split();
                string name = parst[0];
                int age = int.Parse(parst[1]);
                Person person = new Person(name, age);
                family.AddMember(person);
            }

            Person oldest = family.GetOldestMember();
            Console.WriteLine($"{oldest.Name} {oldest.Age}");
            
            /*
            Person person = new Person();
            person.Name = name; 
            person.Age = age;


            var pesho = new Person("Pesho", 20);
            var pesho2 = new Person
            {
                Name = "Pesho",
                Age= 20,
            };



            var gosho = new Person("Gosho", 18);
            var stamat = new Person("Stamat", 43);
            */

        }
    }
}