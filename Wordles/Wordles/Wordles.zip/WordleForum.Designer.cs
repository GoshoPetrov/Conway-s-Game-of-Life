﻿namespace Wordles
{
    partial class WordleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnHint = new System.Windows.Forms.Button();
            this.labelInstructions = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox1.Location = new System.Drawing.Point(31, 66);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox1.MaxLength = 1;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(31, 28);
            this.textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox2.Location = new System.Drawing.Point(68, 66);
            this.textBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox2.MaxLength = 1;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(31, 28);
            this.textBox2.TabIndex = 1;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox3.Location = new System.Drawing.Point(105, 66);
            this.textBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox3.MaxLength = 1;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(31, 28);
            this.textBox3.TabIndex = 2;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox4.Location = new System.Drawing.Point(142, 66);
            this.textBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox4.MaxLength = 1;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(31, 28);
            this.textBox4.TabIndex = 3;
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox5.Location = new System.Drawing.Point(179, 66);
            this.textBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox5.MaxLength = 1;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(31, 28);
            this.textBox5.TabIndex = 4;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox6.Location = new System.Drawing.Point(31, 96);
            this.textBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox6.MaxLength = 1;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(31, 28);
            this.textBox6.TabIndex = 5;
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox7.Location = new System.Drawing.Point(68, 96);
            this.textBox7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox7.MaxLength = 1;
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(31, 28);
            this.textBox7.TabIndex = 6;
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox8.Location = new System.Drawing.Point(105, 96);
            this.textBox8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox8.MaxLength = 1;
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(31, 28);
            this.textBox8.TabIndex = 7;
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox9.Location = new System.Drawing.Point(142, 96);
            this.textBox9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox9.MaxLength = 1;
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(31, 28);
            this.textBox9.TabIndex = 8;
            // 
            // textBox11
            // 
            this.textBox11.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox11.Location = new System.Drawing.Point(179, 96);
            this.textBox11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox11.MaxLength = 1;
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(31, 28);
            this.textBox11.TabIndex = 9;
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox10.Location = new System.Drawing.Point(31, 126);
            this.textBox10.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox10.MaxLength = 1;
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(31, 28);
            this.textBox10.TabIndex = 10;
            // 
            // textBox13
            // 
            this.textBox13.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox13.Location = new System.Drawing.Point(68, 126);
            this.textBox13.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox13.MaxLength = 1;
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(31, 28);
            this.textBox13.TabIndex = 11;
            // 
            // textBox14
            // 
            this.textBox14.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox14.Location = new System.Drawing.Point(105, 126);
            this.textBox14.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox14.MaxLength = 1;
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(31, 28);
            this.textBox14.TabIndex = 12;
            // 
            // textBox15
            // 
            this.textBox15.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox15.Location = new System.Drawing.Point(142, 126);
            this.textBox15.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox15.MaxLength = 1;
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(31, 28);
            this.textBox15.TabIndex = 13;
            // 
            // textBox16
            // 
            this.textBox16.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox16.Location = new System.Drawing.Point(179, 126);
            this.textBox16.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox16.MaxLength = 1;
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(31, 28);
            this.textBox16.TabIndex = 14;
            // 
            // textBox12
            // 
            this.textBox12.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox12.Location = new System.Drawing.Point(179, 156);
            this.textBox12.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox12.MaxLength = 1;
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(31, 28);
            this.textBox12.TabIndex = 19;
            // 
            // textBox17
            // 
            this.textBox17.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox17.Location = new System.Drawing.Point(142, 156);
            this.textBox17.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox17.MaxLength = 1;
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(31, 28);
            this.textBox17.TabIndex = 18;
            // 
            // textBox18
            // 
            this.textBox18.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox18.Location = new System.Drawing.Point(105, 156);
            this.textBox18.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox18.MaxLength = 1;
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(31, 28);
            this.textBox18.TabIndex = 17;
            // 
            // textBox19
            // 
            this.textBox19.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox19.Location = new System.Drawing.Point(68, 156);
            this.textBox19.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox19.MaxLength = 1;
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(31, 28);
            this.textBox19.TabIndex = 16;
            // 
            // textBox20
            // 
            this.textBox20.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox20.Location = new System.Drawing.Point(31, 156);
            this.textBox20.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox20.MaxLength = 1;
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(31, 28);
            this.textBox20.TabIndex = 15;
            // 
            // textBox21
            // 
            this.textBox21.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox21.Location = new System.Drawing.Point(179, 186);
            this.textBox21.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox21.MaxLength = 1;
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(31, 28);
            this.textBox21.TabIndex = 24;
            // 
            // textBox22
            // 
            this.textBox22.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox22.Location = new System.Drawing.Point(142, 186);
            this.textBox22.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox22.MaxLength = 1;
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(31, 28);
            this.textBox22.TabIndex = 23;
            // 
            // textBox23
            // 
            this.textBox23.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox23.Location = new System.Drawing.Point(105, 186);
            this.textBox23.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox23.MaxLength = 1;
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(31, 28);
            this.textBox23.TabIndex = 22;
            // 
            // textBox24
            // 
            this.textBox24.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox24.Location = new System.Drawing.Point(68, 186);
            this.textBox24.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox24.MaxLength = 1;
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(31, 28);
            this.textBox24.TabIndex = 21;
            // 
            // textBox25
            // 
            this.textBox25.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox25.Location = new System.Drawing.Point(31, 186);
            this.textBox25.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox25.MaxLength = 1;
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(31, 28);
            this.textBox25.TabIndex = 20;
            // 
            // textBox26
            // 
            this.textBox26.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox26.Location = new System.Drawing.Point(179, 216);
            this.textBox26.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox26.MaxLength = 1;
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(31, 28);
            this.textBox26.TabIndex = 29;
            // 
            // textBox27
            // 
            this.textBox27.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox27.Location = new System.Drawing.Point(142, 216);
            this.textBox27.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox27.MaxLength = 1;
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(31, 28);
            this.textBox27.TabIndex = 28;
            // 
            // textBox28
            // 
            this.textBox28.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox28.Location = new System.Drawing.Point(105, 216);
            this.textBox28.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox28.MaxLength = 1;
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(31, 28);
            this.textBox28.TabIndex = 27;
            // 
            // textBox29
            // 
            this.textBox29.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox29.Location = new System.Drawing.Point(68, 216);
            this.textBox29.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox29.MaxLength = 1;
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(31, 28);
            this.textBox29.TabIndex = 26;
            // 
            // textBox30
            // 
            this.textBox30.Font = new System.Drawing.Font("Tahoma", 10F);
            this.textBox30.Location = new System.Drawing.Point(31, 216);
            this.textBox30.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox30.MaxLength = 1;
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(31, 28);
            this.textBox30.TabIndex = 25;
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(264, 88);
            this.btnReset.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(110, 43);
            this.btnReset.TabIndex = 30;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(264, 139);
            this.btnSubmit.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(110, 43);
            this.btnSubmit.TabIndex = 31;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            // 
            // btnHint
            // 
            this.btnHint.Location = new System.Drawing.Point(264, 190);
            this.btnHint.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnHint.Name = "btnHint";
            this.btnHint.Size = new System.Drawing.Size(110, 43);
            this.btnHint.TabIndex = 32;
            this.btnHint.Text = "Hint";
            this.btnHint.UseVisualStyleBackColor = true;
            // 
            // labelInstructions
            // 
            this.labelInstructions.AutoSize = true;
            this.labelInstructions.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.labelInstructions.Location = new System.Drawing.Point(50, 27);
            this.labelInstructions.Name = "labelInstructions";
            this.labelInstructions.Size = new System.Drawing.Size(123, 16);
            this.labelInstructions.TabIndex = 33;
            this.labelInstructions.Text = " Move with <- and ->";
            // 
            // WordleForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(419, 309);
            this.Controls.Add(this.labelInstructions);
            this.Controls.Add(this.btnHint);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.textBox26);
            this.Controls.Add(this.textBox27);
            this.Controls.Add(this.textBox28);
            this.Controls.Add(this.textBox29);
            this.Controls.Add(this.textBox30);
            this.Controls.Add(this.textBox21);
            this.Controls.Add(this.textBox22);
            this.Controls.Add(this.textBox23);
            this.Controls.Add(this.textBox24);
            this.Controls.Add(this.textBox25);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.MaximumSize = new System.Drawing.Size(437, 356);
            this.MinimumSize = new System.Drawing.Size(437, 356);
            this.Name = "WordleForm";
            this.Text = "Wordle";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnHint;
        private System.Windows.Forms.Label labelInstructions;
    }
}

